# Multi-Backend LLM Router

**Seamlessly switch between multiple LLM models across SGLang, vLLM, and TabbyAPI backends with real-time status updates and performance metrics.**

Perfect for use with Open-WebUI and other OpenAI-compatible clients!

## ✨ Features

- 🔄 **Automatic Model Switching** - Switch models on-the-fly with streaming status updates
- 📊 **Performance Metrics** - Real-time tok/s reporting appended to responses
- 🎯 **Multi-Backend Support** - Works with SGLang, vLLM, and TabbyAPI
- 🔌 **OpenAI-Compatible API** - Drop-in replacement for OpenAI API
- ⚙️ **Easy Configuration** - YAML-based configuration with interactive installer
- 🚀 **Systemd Integration** - Auto-start on boot with service management
- 📝 **Streaming Updates** - Shows loading progress in real-time during model switches

## 🎬 Demo

When you request a different model, the router automatically:
1. Shows "🔄 Switching to model-name..."
2. Displays loading progress: "⏳ Loading model... 45s / 180s"
3. Confirms readiness: "✅ Model ready! (52s)"
4. Streams the response
5. Appends performance: "⚡ 23.4 tok/s (~125 tokens in 5.3s)"

## 📋 Requirements

- Ubuntu 20.04+ / Debian 11+
- Python 3.10+
- One or more of: SGLang, vLLM, or TabbyAPI
- systemd (for service management)
- sudo/root access for installation

## 🚀 Quick Start

### 1. Download

```bash
git clone https://github.com/yourusername/multi-backend-llm-router.git
cd multi-backend-llm-router
```

### 2. Run Interactive Installer

```bash
sudo ./install.sh
```

The installer will prompt you for:
- Install directory (default: `/opt/llm-router`)
- Router port (default: `8002`)
- Backend configurations (SGLang/vLLM/TabbyAPI ports and hosts)

### 3. Configure Your Models

Edit `/etc/llm-router/models.yml`:

```yaml
# SGLang/vLLM models with startup scripts
mistral-large-awq:
  backend: sglang
  script: /home/user/models/start_mistral.sh
  service: sglang.service

llama-70b-awq:
  backend: sglang
  script: /home/user/models/start_llama.sh
  service: sglang.service

# TabbyAPI models (no script needed)
magnum-123b-exl2:
  backend: tabbyapi
  script: null
  service: tabbyapi.service
  model_name: Magnum-123B-4.0bpw
```

### 4. Start the Router

```bash
sudo systemctl start llm-router
sudo systemctl enable llm-router  # Auto-start on boot
```

### 5. Use with Open-WebUI

In Open-WebUI settings:
- **API URL**: `http://localhost:8002/v1`
- **API Key**: (leave empty or any value)

All your configured models will appear in the model dropdown!

## 📖 Configuration

### Backend Configuration (`/etc/llm-router/config.yml`)

```yaml
router_port: 8002
model_load_timeout: 180

backends:
  sglang:
    host: "localhost"
    port: 30000
    service: "sglang.service"
    health_endpoint: "/health"
  
  vllm:
    host: "localhost"
    port: 8000
    service: "vllm.service"
    health_endpoint: "/health"
  
  tabbyapi:
    host: "localhost"
    port: 5000
    service: "tabbyapi.service"
    health_endpoint: "/health"
```

### Model Configuration (`/etc/llm-router/models.yml`)

Each model entry requires:
- `backend`: Which backend to use (`sglang`, `vllm`, or `tabbyapi`)
- `script`: (Optional) Path to startup script for SGLang/vLLM models
- `service`: systemd service name for the backend
- `model_name`: (TabbyAPI only) Model directory name

## 🔧 Usage Examples

### With curl

```bash
# List available models
curl http://localhost:8002/v1/models

# Chat completion (streaming)
curl http://localhost:8002/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "mistral-large-awq",
    "messages": [{"role": "user", "content": "Hello!"}],
    "stream": true
  }'
```

### With Python (OpenAI library)

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:8002/v1",
    api_key="not-needed"
)

response = client.chat.completions.create(
    model="llama-70b-awq",
    messages=[{"role": "user", "content": "Explain quantum computing"}],
    stream=True
)

for chunk in response:
    print(chunk.choices[0].delta.content, end="")
```

## 🛠️ Management

### Service Management

```bash
# Start router
sudo systemctl start llm-router

# Stop router
sudo systemctl stop llm-router

# Restart router
sudo systemctl restart llm-router

# View status
sudo systemctl status llm-router

# Enable auto-start on boot
sudo systemctl enable llm-router

# Disable auto-start
sudo systemctl disable llm-router
```

### Logs

```bash
# View live logs
journalctl -u llm-router -f

# View recent logs
journalctl -u llm-router -n 100

# View logs since boot
journalctl -u llm-router -b
```

### Health Check

```bash
curl http://localhost:8002/health
```

Response:
```json
{
  "status": "healthy",
  "current_model": "mistral-large-awq",
  "backends": {
    "sglang": true,
    "tabbyapi": false
  },
  "models": ["mistral-large-awq", "llama-70b-awq", "magnum-123b-exl2"]
}
```

## 🔍 Troubleshooting

### Router won't start

1. Check logs: `journalctl -u llm-router -n 50`
2. Verify Python environment: `ls -la /opt/llm-router/venv`
3. Check config syntax: `python3 -c "import yaml; yaml.safe_load(open('/etc/llm-router/config.yml'))"`

### Models not appearing

1. Verify `/etc/llm-router/models.yml` syntax
2. Check that backend services are accessible
3. Test backend health: `curl http://localhost:30000/health` (adjust port)

### Model switching fails

1. Ensure backend services exist: `systemctl list-units | grep sglang`
2. Check service permissions: router must run as user with systemctl access
3. Verify startup scripts are executable: `ls -la /path/to/script.sh`

### Performance metrics not showing

- Metrics are appended after response completes
- For streaming: appears before `[DONE]`
- For non-streaming: added to response content

## 🏗️ Architecture

```
┌──────────────┐
│  Open-WebUI  │
│  or Client   │
└──────┬───────┘
       │ HTTP
       │ (OpenAI API)
       ▼
┌──────────────┐
│  LLM Router  │  ← This project
│  (Port 8002) │
└──────┬───────┘
       │
       ├───────────┐
       │           │
       ▼           ▼
  ┌────────┐  ┌─────────┐
  │ SGLang │  │ TabbyAPI│
  │  :30000│  │  :5000  │
  └────────┘  └─────────┘
```

## 🤝 Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Test your changes
4. Submit a pull request

## 📝 License

MIT License - See LICENSE file for details

## 🙏 Acknowledgments

Built to solve the common pain point of model switching in Open-WebUI with vLLM/SGLang.

Special thanks to the communities behind:
- [SGLang](https://github.com/sgl-project/sglang)
- [vLLM](https://github.com/vllm-project/vllm)
- [TabbyAPI](https://github.com/theroyallab/tabbyAPI)
- [Open-WebUI](https://github.com/open-webui/open-webui)

## 📧 Support

- **Issues**: GitHub Issues
- **Discussions**: GitHub Discussions

---

**Made with ❤️ for the LLM community**
