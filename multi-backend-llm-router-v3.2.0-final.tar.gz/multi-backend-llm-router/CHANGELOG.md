# Changelog

## [3.2.0] - 2025-10-25

### Added
- **llama.cpp Support**: Full integration for GGUF quantized models
- llamacpp backend with streaming status updates
- `llamacpp.service.template` systemd service file
- Example startup scripts for Behemoth and Magnum GGUF models
- Blackwell GPU (sm_90) build instructions in README

### Fixed
- Backend cleanup now stops ALL services when switching (sglang, tabbyapi, llamacpp)
- Added `pkill -9 llama-server` to prevent orphaned processes
- Proper LLAMACPP_URL routing in all proxy functions

### Changed
- Updated README with llama.cpp setup and usage
- Router now handles 3 backends: SGLang (AWQ), TabbyAPI (EXL2), llama.cpp (GGUF)
- Improved model switching logic with backend detection

## [3.1.1] - 2025-10-24

### Added
- Token/s performance metrics appended to responses
- `[Performance: XX.X tok/s | N tokens in X.XXs]` format

### Fixed
- Improved TabbyAPI model switching reliability
- Better warmup handling (5s delay after ready signal)
- More robust health checks

## [3.0.0] - 2025-10-23

### Added
- Initial multi-backend router release
- SGLang (AWQ) support
- TabbyAPI (EXL2) support
- Streaming status updates during model loading
- Open-WebUI compatibility
- Systemd service management
- Health checks and timeout handling
