# Installation Verification Checklist

## Pre-Installation Requirements

### System
- [ ] Ubuntu/Debian Linux
- [ ] Python 3.10+
- [ ] systemd available
- [ ] Root/sudo access

### For llama.cpp Support
- [ ] CUDA Toolkit installed (12.0+)
- [ ] NVIDIA GPU with compute capability (Blackwell = sm_90)
- [ ] GCC 13 or compatible compiler
- [ ] CMake 3.18+

### Backends (Install at least one)
- [ ] SGLang installed (for AWQ models)
- [ ] TabbyAPI installed (for EXL2 models)  
- [ ] llama.cpp built with CUDA (for GGUF models)

## Installation Steps

1. **Extract Package**
   ```bash
   tar -xzf multi-backend-llm-router-v3.2.0-final.tar.gz
   cd multi-backend-llm-router
   ```

2. **Run Installer**
   ```bash
   sudo ./install.sh
   ```

3. **Verify Installation**
   ```bash
   # Check router service
   sudo systemctl status model-router
   
   # Test health endpoint
   curl http://localhost:8002/health
   
   # List models
   curl http://localhost:8002/v1/models
   ```

## Post-Installation Configuration

### Add Models

Edit router configuration to add your models. The router script uses a MODELS dictionary:

```python
MODELS = {
    "your-model-name": {
        "backend": "sglang",  # or "tabbyapi" or "llamacpp"
        "script": "/path/to/start_script.sh",
        "service": "sglang.service"  # or "tabbyapi.service" or "llamacpp.service"
    }
}
```

### Create Startup Scripts

For llama.cpp models, create scripts like:

```bash
#!/bin/bash
cd /path/to/llama.cpp/build
exec ./bin/llama-server \
    -m /path/to/model.gguf \
    -ngl 999 \
    --port 8085 \
    --host 0.0.0.0 \
    -c 4096
```

Make executable: `chmod +x script.sh`

### Enable Auto-Start

```bash
sudo systemctl enable model-router
sudo systemctl enable sglang        # if using SGLang
sudo systemctl enable tabbyapi      # if using TabbyAPI
sudo systemctl enable llamacpp      # if using llama.cpp
```

## Testing

### Test Model Switching

1. Open Open-WebUI at your configured address
2. Add connection: `http://localhost:8002/v1`
3. Select different models from dropdown
4. Verify:
   - Loading status appears
   - Model switches successfully
   - GPU memory shows correct backend loaded
   - Responses work correctly

### Monitor Logs

```bash
# Router logs
sudo journalctl -u model-router -f

# Backend logs
sudo journalctl -u sglang -f
sudo journalctl -u tabbyapi -f
sudo journalctl -u llamacpp -f

# GPU usage
watch -n 1 nvidia-smi
```

## Common Issues

### Port Already in Use
- Check: `lsof -i :8002`
- Kill process: `kill <PID>`

### Model Won't Load
- Check backend service: `systemctl status <service>`
- Check logs: `journalctl -u <service> -n 50`
- Verify VRAM available: `nvidia-smi`

### llama-server Orphaned Process
- Kill manually: `pkill -9 llama-server`
- Router should auto-cleanup in v3.2.0+

### Backend Health Check Fails
- Verify backend is actually running
- Check firewall: `sudo ufw status`
- Test directly: `curl http://localhost:<port>/health`

## Support

For issues, check:
- README.md for detailed documentation
- CHANGELOG.md for version changes
- GitHub issues (if repository is public)
